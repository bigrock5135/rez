﻿var app = angular.module('main', ['ngMaterial']);

app.controller('ReportCtrl', function ($scope, $http) {
    $scope.reports = [] //['Who owns', '13 G/F']
    $scope.symbols = [] //['Ticker', 'ML SEC', 'CU SIP']
    $scope.today = new Date();
   
    $scope.reportType$required = false;
    $scope.symbolType$required = false;
    $scope.reportDate$required = false;
    $scope.requestDetails$required = false;
    $scope.message$error = false;
    $scope.reports$error = false;

    //get the reports metadata
    $http.get('/api/report/GetReportMetadata')
        .then(function (response) {
            $scope.reports = response.data.reportTypes;
            
            $scope.symbols = response.data.securityTypes;
            
            $scope.queuedReports = response.data.reports.filter(function (item) {
                return item.report === $scope.selectedReport && item.pending==true;
            })
            
        });


    $scope.dateChange = function ()
    {
        $scope.reportDate$required = false;
        $scope.message$error = false;
    }

    //load reports by filters
    $scope.loadReports = function () {

        $scope.reportType$required = false;
        $scope.reports$error = false;

        $http.get('/api/report/GetReport')
            .then(function (response) {
                
                $scope.queuedReports = response.data.filter(function (item) {
                    return item.report == $scope.selectedReport && item.pending==true;
                });                

            });
    };
    
    $scope.validateRequest = function () {

        $scope.reportType$required = false;
        $scope.symbolType$required = false;
        $scope.reportDate$required = false;
        $scope.requestDetails$required = false;
        $scope.message$error = false;
        $scope.reports$error = false;

        var msg = "";
        
        if ($scope.selectedReport == "" || $scope.selectedReport == undefined ) { 
            $scope.reportType$required = true;
            if (msg!="") msg += "\n";
            msg += "Report Type is missing";
        }

        if ($scope.selectedSymbol == "" || $scope.selectedSymbol == undefined) {
            $scope.symbolType$required = true;
            if (msg != "") msg += "\n";
            msg += "Symbol Type is missing";
        }

        if ($scope.reportDate == "" || $scope.reportDate == undefined) {
            $scope.reportDate$required = true;
            $scope.message$error = true;
            if (msg != "") msg += "\n";
            msg += "Data is missing";
        }
        
        if ($scope.requestDetails == "" || $scope.requestDetails == undefined) {
            $scope.requestDetails$required = true;
            if (msg != "") msg += "\n";
            msg += "Symbol details are missing";
        }
              

        return msg;

    }

    //save the report schedule
    $scope.createReport = function () {

        var msg = $scope.validateRequest();

        if (msg == "") {
            var newReport = {
                report: $scope.selectedReport,
                symbol: $scope.selectedSymbol,
                date: $scope.reportDate,
                details: $scope.requestDetails,
                who_sch: "Kanishk",
                pending: true
            }

            $http.post('/api/report/save', newReport)
                .then(function () {
                    $http.get('/api/report/GetReportMetadata')
                        .then(function (reports) {
                            $scope.showMessage = true;
                            $scope.queuedReports = reports.data.reports.filter(function (report) {
                                return report.report == newReport.report && report.pending == true;
                            })
                        }).catch(function (err) {
                            console.log(err);
                        })
                }).catch(function (err) {
                    console.log(err);
                })
        }
        else
        {
            
            $scope.reports$error = true;

            alert("Important details are missing!" + "\n\n" + msg);
        }

        
    }


   
});