﻿var app = angular.module('main', ['ngMaterial']);

app.controller('ReportCtrl', function ($scope, $http) {
    $scope.reports = [] //['Who owns', '13 G/F']
    $scope.symbols = [] //['Ticker', 'ML SEC', 'CU SIP']
    $scope.today = new Date();
    $scope.reportDate = new Date();
       

    //get the reports metadata
    $http.get('/api/report/GetReportMetadata')
        .then(function (response) {
            $scope.reports = response.data.reportTypes;
            $scope.selectedReport = response.data.reportTypes[0];

            $scope.symbols = response.data.securityTypes;
            $scope.selectedSymbol = response.data.securityTypes[0];

            $scope.queuedReports = response.data.reports.filter(function (item) {
                return item.report === $scope.selectedReport && item.pending==true;
            })
            
        });


    //load reports by filters
    $scope.loadReports = function () {
        $http.get('/api/report/GetReport')
            .then(function (response) {
                
                $scope.queuedReports = response.data.filter(function (item) {
                    return item.report == $scope.selectedReport && item.pending==true;
                });                

            });
    };
    
    //save the report schedule
    $scope.createReport = function () {
        var newReport = {
            report: $scope.selectedReport,
            symbol: $scope.selectedSymbol,
            date: $scope.reportDate,
            details: $scope.requestDetails,
            who_sch: "Kanishk",
            pending: true
        }

        $http.post('/api/report/save', newReport)
            .then(function () {
                $http.get('/api/report/GetReportMetadata')
                    .then(function (reports) {
                        $scope.showMessage = true;
                        $scope.queuedReports = reports.data.reports.filter(function (report) {
                            return report.report == newReport.report && report.pending == true;
                        })
                    }).catch(function (err) {
                        console.log(err);
                    })
            }).catch(function (err) {
                console.log(err);
            })
    }
});