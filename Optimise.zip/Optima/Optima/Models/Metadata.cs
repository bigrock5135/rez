﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Optima.Models
{
    public class Metadata
    {
        public List<String> reportTypes { get; set; }
        public List<String> securityTypes { get; set; }
        public List<Report> reports { get; set; }
    }
}