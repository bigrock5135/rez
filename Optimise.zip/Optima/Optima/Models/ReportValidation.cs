﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Optima.Models
{
    public class ReportValidation
    {

        public bool validationResult { get; set; }

        public bool report { get; set; }
        public bool symbol { get; set; }
        public bool date { get; set; }
        public bool details { get; set; }

    }
}