﻿var app = angular.module('main', ['ngMaterial']);

app.controller('ReportCtrl', function ($scope, $http) {
    $scope.reports = [] //['Who owns', '13 G/F']
    $scope.symbols = [] //['Ticker', 'ML SEC', 'CU SIP']
    $scope.today = new Date();
   
    $scope.reportType$required = false;
    $scope.symbolType$required = false;
    $scope.reportDate$required = false;
    $scope.requestDetails$required = false;
    $scope.message$error = false;
    $scope.reports$error = false;

    //get the reports metadata
    $http.get('/api/report/GetReportMetadata')
        .then(function (response) {
            $scope.reports = response.data.reportTypes;
            
            $scope.symbols = response.data.securityTypes;
            
            $scope.queuedReports = response.data.reports.filter(function (item) {
                return item.report === $scope.selectedReport && item.pending==true;
            })
            
        });


    $scope.dateChange = function ()
    {
        $scope.reportDate$required = false;
        $scope.message$error = false;
    }

    //load reports by filters
    $scope.loadReports = function () {

        $scope.reportType$required = false;
        $scope.reports$error = false;

        $http.get('/api/report/GetReport')
            .then(function (response) {
                
                $scope.queuedReports = response.data.filter(function (item) {
                    return item.report == $scope.selectedReport && item.pending==true;
                });                

            });
    };
    
    $scope.validateRequest = function (response) {

        $scope.reportType$required = false;
        $scope.symbolType$required = false;
        $scope.reportDate$required = false;
        $scope.requestDetails$required = false;
        $scope.message$error = false;
        $scope.reports$error = false;

        var msg = "";
        
        if (!response.data.report) {
            $scope.reportType$required = true;
            if (msg!="") msg += "\n";
            msg += "Report Type is missing";
        }

        if (!response.data.symbol) {
            $scope.symbolType$required = true;
            if (msg != "") msg += "\n";
            msg += "Symbol Type is missing";
        }

        if (!response.data.data) {
            $scope.reportDate$required = true;
            $scope.message$error = true;
            if (msg != "") msg += "\n";
            msg += "Data is missing";
        }
        
        if (!response.data.details) {
            $scope.requestDetails$required = true;
            if (msg != "") msg += "\n";
            msg += "Symbol details are missing";
        }
              

        if (msg != "") {
            $scope.reports$error = true;
            alert("Important details are missing!" + "\n\n" + msg);
        }

    }

    //save the report schedule
    $scope.createReport = function () {

        var newReport = {
            report: $scope.selectedReport,
            symbol: $scope.selectedSymbol,
            date: $scope.reportDate,
            details: $scope.requestDetails,
            who_sch: "Kanishk",
            pending: true
        }

        $http.post('/api/report/save', newReport)
                .then(function (response) {

                    if (response.data.validationResult) {
                        $http.get('/api/report/GetReportMetadata')
                        .then(function (reports) {
                            $scope.showMessage = true;
                            $scope.queuedReports = reports.data.reports.filter(function (report) {
                                return report.report == newReport.report && report.pending == true;
                            })
                        }).catch(function (err) {
                            console.log(err);
                        })
                    }
                    else {
                        $scope.validateRequest(response);
                    }
                    

                }).catch(function (err) {
                    console.log(err);
                })



        

        
    }


   
});