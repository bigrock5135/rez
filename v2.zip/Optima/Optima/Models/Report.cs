﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Optima.Models
{
    public class Report
    {
        public string report { get; set; }
        public string symbol { get; set; }
        public DateTime date { get; set; }
        public string details { get; set; }
        public string who_sch { get; set; }
    }
}