﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Optima.Models;

namespace Optima.Controllers
{
    public class ReportController : ApiController
    {

        private List<Report> listOfReports;

        private List<Report> getListReports()
        {
            if (System.Web.HttpContext.Current.Session["Reports"] == null)
            {
                this.listOfReports = new List<Report>();

                Report aux = new Report() { date = DateTime.Now, details = "stub", report = "Who owns", symbol = "Ticker", who_sch = "Kanishk" };
                this.listOfReports.Add(aux);

                aux = new Report() { date = DateTime.Now, details = "stub", report = "13 G/F", symbol = "Ticker", who_sch = "Kanishk" };
                this.listOfReports.Add(aux);

                System.Web.HttpContext.Current.Session["Reports"] = this.listOfReports;
            }

            this.listOfReports = (List<Report>)System.Web.HttpContext.Current.Session["Reports"];

            return this.listOfReports;

        }

        /// <summary>
        ///     Method: GetReportMetadata
        ///     Output: list of reports, list of security type, report information
        /// </summary>
        /// <returns></returns>
        public Metadata GetReportMetadata()
        {
            Metadata obj = new Metadata();

            obj.reportTypes = new List<string>();
            obj.reportTypes.Add("Who owns");
            obj.reportTypes.Add("13 G/F");

            obj.securityTypes = new List<string>();
            obj.securityTypes.Add("Ticker");
            obj.securityTypes.Add("ML SEC");
            obj.securityTypes.Add("CU SIP");

            obj.reports = new List<Report>();
            obj.reports.AddRange(getListReports());

            return obj;
        }

        /// <summary>
        /// Method: GetReport
        /// Output: List of report that are scheduled
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Report> GetReport()
        {
            return getListReports();
        }


        /// <summary>
        /// Method: SaveReport
        /// Input: reportType, symbol Type, symbol Details, report Date
        /// Output: success/failure
        /// </summary>
        /// <param name="value"></param>
        public void Save([FromBody] Report rep)
        {
            this.getListReports().Add(rep);
        }


    }
}